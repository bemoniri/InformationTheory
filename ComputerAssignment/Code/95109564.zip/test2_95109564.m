%% Channel A
A = [0.7, 0.2, 0.1; 0.1, 0.2, 0.7];
BlahutArimoto_95109564(A)

%% Channel C
B = [0.7, 0.3, 0; 0, 0.3, 0.7];
BlahutArimoto_95109564(B)